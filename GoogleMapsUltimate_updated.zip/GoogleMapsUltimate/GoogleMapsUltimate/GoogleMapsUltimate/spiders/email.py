import csv
import re
from copy import deepcopy

import scrapy


class EmailSpider(scrapy.Spider):
    name = "email"
    custom_settings = {
        'FEED_URI': 'output_email.csv',
        'FEED_FORMAT': 'csv',
        'FEED_EXPORT_ENCODING': 'utf-8',
        'HTTP_ERROR_ALLOW_ALL': True,
    }

    start_urls = ['https://quotes.toscrape.com/']

    def is_valid_email(self, email):
        # Regular expression pattern for a basic email format
        pattern = r'^[\w\.-]+@[\w\.-]+\.[a-zA-Z]{2,}$'

        return re.match(pattern, email) is not None

    def parse(self, response):
        # scraped_data_1 = []
        # for scraped_list in list(csv.DictReader(open('outputs/google_business_flanders_andre_media_email.csv', 'r'))):
        #     if scraped_list.get('Bussiness_Contact') not in scraped_data_1:
        #         scraped_data_1.append(scraped_list.get('Bussiness_Contact'))
        #         yield scraped_list
        #
        # df = pd.read_excel('google_business_flanders_andre_media_without_email.xlsx')
        # data_dict = df.to_dict(orient='records')
        # for p in data_dict:
        #     item = deepcopy(p)
        #     item['emails'] = ''
        #     try:
        #         if item.get('Bussiness_Contact') not in scraped_data_1:
        #             scraped_data_1.append(item.get('Bussiness_Contact'))
        #             yield item
        #     except:
        #         yield item
        records = list(csv.DictReader(open('output.csv', mode='r', newline='', encoding='utf-8')))
        for record in records:
            url = record.get('Website', '')
            if url:
                if not url.startswith('http'):
                    # Only add 'https://' for URLs that don't have it
                    if 'www.' in url:
                        yield scrapy.Request(url=url, callback=self.parse_emails, meta={'item':record},
                                             dont_filter=True)
                    else:
                        yield scrapy.Request(url='https://www.' + url,
                                             dont_filter=True,
                                             callback=self.parse_emails, meta={'item':record})
                else:
                    # If the URL already has http/https, make the request directly
                    yield scrapy.Request(url=url, callback=self.parse_emails, meta={'item':record},
                                         dont_filter=True)
            else:
                record['emails'] = ''
                yield record

    def parse_emails(self, response):
        item = response.meta['item']
        final_emails = []
        try:
            # Improved regex for TLDs
            regex = r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"

            # Extract email addresses using the regex
            matches = re.findall(regex, response.text)

            if matches:
                extracted_emails = list(set(matches))  # Remove duplicates
                print("Extracted emails:")
                for email in extracted_emails:
                    if '.png' not in email and '.jpg' not in email and 'wix@' not in email and 'wixpress.' not in email and '@sentry.io' not in email:
                        final_emails.append(email)
            else:
                print("No email addresses found in the text.")

        except re.error as e:
            print(f"Error: Invalid regex pattern - {e}")
        # You can add more specific exception handling here

        item['emails'] = final_emails
        yield item
