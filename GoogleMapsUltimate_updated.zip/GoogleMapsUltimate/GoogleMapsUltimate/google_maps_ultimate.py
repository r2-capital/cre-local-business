import csv
from datetime import datetime
import random
from typing import Union
import scrapy
from scrapy import Selector, Spider
import time
import undetected_chromedriver as uc
from selenium.common import NoSuchElementException, TimeoutException
from selenium.webdriver.common.by import By
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support import expected_conditions as EC
from twisted.internet.defer import Deferred


class GoogleMapsScraper:
    url = "https://www.google.ca/maps"
    csv_header = ['Name', 'Address', 'Rating', 'Result Count', 'Phone no', 'Website', "Facebook", 'Location URL', 'Search Query', 'Longitude', 'Latitude']
    header=False

    def __init__(self, email='', password='',sender_name='', send_to_email='',game_url='', **kwargs, ):
        super().__init__()
        self.readCsv()

    def readCsv(self):
        keywords = []
        cities = []
        with open("input/keywords.csv", 'r') as file:
            csvreader = [x for x in csv.DictReader(file)]
            for row in csvreader:
                keywords.append(row.get('Keywords'))
        with open("input/locations.csv", 'r') as file:
            csvreader = [x for x in csv.DictReader(file)]
            for row in csvreader:
                cities.append(row.get('city', ''))
        for keyword in keywords:
            for city in cities:
                # try:
                search_query = '{} in {}, USA'.format(keyword, city)
                self.beginScraping(search_query)
                # except Exception as e:
                #     pass



    def beginScraping(self, search_query):
        self.get_driver()
        self.wait = WebDriverWait(self.driver, timeout=5, poll_frequency=1)
        self.driver.get(self.url)
        try:
            clear_button = self.driver.find_element(By.CSS_SELECTOR, 'button.vhHbVe')
            clear_button.click()
        except Exception:
            pass

        searchbox = self.driver.find_element(By.ID, 'searchboxinput')
        searchbox.send_keys(search_query)
        self.driver.find_element(By.ID, 'searchbox-searchbutton').click()
        time.sleep(3)
        self.scroll()

        print('hi')
        self.parse_listing(search_query)


    def parse_listing(self, search_query):
        entries = self.wait.until(lambda d: d.find_elements(By.CLASS_NAME, "hfpxzc"))
        for i, entry in enumerate(entries):
            try:
                actions = ActionChains(self.driver)
                actions.key_down(Keys.CONTROL).click(entry).key_up(Keys.CONTROL).perform()
            except Exception as e:
                continue

            try:
                for window_handle in self.driver.window_handles:
                    if window_handle != self.original_window:
                        self.driver.switch_to.window(window_handle)
                        break

                try:
                    detail_data = self.parse_detail()
                    # after extraction logic
                    self.driver.close()
                    self.driver.switch_to.window(self.original_window)
                    time.sleep(2)
                    try:
                        name = entry.get_attribute('aria-label')
                    except Exception:
                        name = ''
                    try:
                        location_url = entry.get_attribute('href')
                        if location_url:
                            try:
                                start_lat = location_url.find("!3d") + 3
                                end_lat = location_url.find("!4d") - 1
                                start_lng = end_lat + 4
                                end_lng = location_url.find("!", start_lng)
                                latitude = location_url[start_lat:end_lat]
                                longitude = location_url[start_lng:end_lng]
                            except Exception:
                                longitude = ''
                                latitude = ''
                        else:
                            longitude = ''
                            latitude = ''
                    except Exception:
                        location_url = ''
                    item = dict()
                    item['Name'] = name
                    facebook = ''
                    try:
                        div_element = entry.find_element(By.XPATH,
                                                         './following-sibling::div[contains(@class, "bfdHYd Ppzolf OFBs3e")]')
                        try:
                            rating = div_element.find_element(By.CSS_SELECTOR, '.ZkP5Je .MW4etd').text
                        except Exception:
                            rating = ''
                        try:
                            address = div_element.find_element(By.XPATH,
                                                               '(.//span[contains(@aria-hidden, "true") and contains(text(), "·")]/following-sibling::span)[2]').text
                            if address:
                                if address.startswith('+'):
                                    address = ''
                        except Exception:
                            address = ''
                        try:
                            phone = div_element.find_element(By.CSS_SELECTOR, '.UsdlK').text
                        except Exception:
                            phone = ''
                        try:
                            website_a_tag = div_element.find_element(By.CSS_SELECTOR, '.lcr4fd.S9kvJb')
                            website = website_a_tag.get_attribute('href')
                            if 'facebook' in website:
                                facebook = website
                        except Exception:
                            website = ''
                            facebook = ''
                        item['Location URL'] = location_url
                        item['Result Count'] = len(entries)
                        item['Search Query'] = search_query
                        item['Address'] = detail_data.get('address', '') if detail_data.get('address', '') else address
                        item['Rating'] = detail_data.get('rating', '') if detail_data.get('rating', '') else rating
                        item['Phone no'] = detail_data.get('phone', '') if detail_data.get('phone', '') else phone
                        item['Website'] = detail_data.get('website', '') if detail_data.get('website', '') else website
                        item['Facebook'] = facebook
                        item['Latitude'] = latitude
                        item['Longitude'] = longitude
                        outputfile = open('output.csv', 'a', encoding='utf-8', newline='')
                        writer = csv.DictWriter(outputfile, fieldnames=self.csv_header)
                        if not self.header:
                            writer.writeheader()
                            self.header = True
                        writer.writerow(item)
                        outputfile.close()
                        print(item)


                    except Exception as e:
                        print(e)
                except Exception:
                    pass

            except Exception as e:
                print('Here is the issue', e)

        self.driver.quit()



    def parse_detail(self):

        self.wait.until(lambda d: d.find_element(By.XPATH, '//button[@data-item-id="address"]'))

        try:
            address=self.driver.find_element(By.XPATH, '//button[@data-item-id="address"]').get_attribute('aria-label').strip('Address: ')
        except:
            address=''
        try:
            website_element=self.driver.find_element(By.XPATH, '//span[text()=""]/parent::div/following-sibling::div[1]')
            self.driver.execute_script("arguments[0].scrollIntoView();", website_element)
            website=website_element.text

        except:
            website=''

        try:
            phone_element = self.driver.find_element(By.XPATH, '//span[text()=""]/parent::div/following-sibling::div[1]')
            self.driver.execute_script("arguments[0].scrollIntoView();", phone_element)
            phone=phone_element.text

        except:
            phone=''
        try:
            rating_element=self.driver.find_element(By.XPATH, '//div[@class="jANrlb "]/div[@class="fontDisplayLarge"]')
            self.driver.execute_script("arguments[0].scrollIntoView();", rating_element)
            # rating=self.driver.find_element(By.XPATH, '//div[@class="jANrlb "]/div[@class="fontDisplayLarge"]').text
            rating=rating_element.text
        except:
            rating=''

        try:
            reviews=self.driver.find_element(By.XPATH, '//span[contains(text(),"reviews")]').text
        except:
            reviews=''

        self.driver.back()
        return {
            'address': address,
            'website': website,
            'phone': phone,
            'rating': rating,
            'reviews': reviews
        }

    def scroll(self):
        try:
            # Increase timeout and use appropriate locator
            element = WebDriverWait(self.driver, 30).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, '.hfpxzc'))  # Change 'hfpxzc' to the actual ID
            )
            print("Element found:", element)
            last_ele_length = len(self.driver.find_elements(By.CLASS_NAME, "hfpxzc"))
            time.sleep(2)
            while True:
                try:
                    self.driver.find_element(By.CSS_SELECTOR, '[role="main"] .ecceSd .ecceSd').send_keys(Keys.END)
                    self.driver.find_element(By.CSS_SELECTOR, '[role="main"] .ecceSd .ecceSd').send_keys(Keys.ARROW_DOWN)
                    time.sleep(random.randint(3, 5))
                    self.driver.implicitly_wait(3)
                    new_ele_length = len(self.driver.find_elements(By.CLASS_NAME, "hfpxzc"))
                    if new_ele_length == last_ele_length:
                        break
                    else:
                        last_ele_length = new_ele_length
                except Exception as e:
                    print(e)
                    break
        except TimeoutException:
            print("Element not found within the given time.")
            # Debug: Print the page source or take a screenshot


    def get_driver(self):
        self.driver=webdriver.Chrome()
        self.driver.maximize_window()
        self.original_window = self.driver.current_window_handle
        self.wait = WebDriverWait(self.driver, timeout=60, poll_frequency=1,
                             ignored_exceptions=[NoSuchElementException, TimeoutException])


if __name__=='__main__':
    scraper=GoogleMapsScraper()
